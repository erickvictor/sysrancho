import React from 'react'
import {useForm, Controller} from 'react-hook-form'
import moment from 'moment'
require('moment/locale/pt-br')
moment.locale('pt-br')
console.log(moment.locale())


export const Appointment = () => {
  const {register, handleSubmit, control} = useForm()

  const onSubmit = (data) => {
    console.log(data)
  }

  var newDays = []
  for (var i = 1; i < 8; i++) {
    console.log(i)
    newDays[i] = moment().add(i, 'days')
  }
  console.log(newDays)
  const formato = 'D/MM/YYYY dddd'
  const formato2 = 'D/MM/YYYY'


  return (
    <div className="my-3 p-3 bg-white rounded shadow-sm">
      <h6 className="border-bottom border-gray pb-2 mb-0">Reserva Refeições</h6>
      <div className="table-responsive">
        <form onSubmit={handleSubmit(onSubmit)}>
        <table className="table">
          <thead>
              <tr className="d-flex">
                  <th className="col align-text-bottom"></th>
                  {
                    newDays.map(item => 
                      <th className="col text-center"  key={item}>
                        { item.format(formato) }
                      </th>
                    )
                  }
              </tr>
          </thead>
          <tbody>
            <tr className="d-flex">
                <th className="col">Café</th>
                {
                  newDays.map(item => 
                    <th className="col text-center"  key={item}>
                      <input className="form-check-input ml-0" name='cafe' value={ item.format(formato2) } type="checkbox" ref={register} />
                    </th>
                  )
                }
            </tr>
            <tr className="d-flex">
                <th className="col">Almoço</th>
                {
                  newDays.map(item => 
                    <th className="col text-center"  key={item}>
                      <input className="form-check-input ml-0" name='almoco' value={ item.format(formato2) } type="checkbox" />
                    </th>
                  )
                }
            </tr>
            <tr className="d-flex">
                <th className="col">Jantar<Controller
                  as={<input />}
                  name="Checkbox"
                  type="checkbox"
                  value='teste'
                  control={control}
                /> 
              </th>
                {
                  newDays.map(item => 
                    <th className="col text-center"  key={item}>
                      <input className="form-check-input ml-0" name='jantar' value={ item.format(formato2) } type="checkbox" />
                    </th>
                  )
                }
            </tr>
            
          </tbody>
        </table>
        </form>
      </div>
      <small className="d-block text-right mt-3">

        <button type="button" className="btn btn-danger btn-sm">Cancelar</button>
        {' '}
        <input type="submit" className="btn btn-success btn-sm" value='Salvar' />
      </small>
    </div>

  )
}
