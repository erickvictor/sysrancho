import React from 'react'

export const Header = () => {
  return (
    <div className="card text-white bg-dark mt-4">
      <div className="card-body">
        Parque Regional de Manutenção 12
      </div>
    </div>
  )
}
